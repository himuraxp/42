		<footer id="footer" class="footer">
			<div class="logo-footer"><h1>Snap Your Face</h1></div>
		</footer>
	</body>
<html>
