<!DOCTYPE HTML5>
<html>
	<head>
	<meta charset="utf-8" />
		<title>CAMAGRU</title>
		<link rel="stylesheet" type="text/css" href="/client/css/style.css" media="all"/>
		<link rel="stylesheet" type="text/css" href="/client/css/body.css" media="all"/>
		<link rel="stylesheet" type="text/css" href="/client/css/header.css" media="all"/>
		<link rel="stylesheet" type="text/css" href="/client/css/footer.css" media="all"/>
		<link rel="stylesheet" type="text/css" href="/client/css/keyframes.css" media="all"/>
		<link rel="stylesheet" type="text/css" href="/client/css/responsive.css" media="all"/>
		<link href='https://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
	</head>
