<?php
$DB_DSN = 'mysql:host=localhost:8889';
$DB_USER = 'root';
$DB_PASSWORD = 'root';
$DB_NAME = 'camagru2';
$DB_TABLE = array(
	'users' => 'users',
	'pictures' => 'pictures',
	'comments' => 'comments',
	'likes' => 'likes'
);
?>
